T = 0.05;
X_Max = 1;

N = [10,20,40,80,160,320];
M = zeros(1, length(N));
MM = zeros(1, length(N));
rate = 20/(10*10); %Two Magic Number, take M = 20, N = 10
rateb = 20/10;
for i = 1:length(N)
    M(i) = rate*N(i)*N(i);
end
for i = 1:length(N)
    MM(i) = rateb*N(i);
end
[l1norm,l2normadj,l2norm] = checknorms(N,M,T,X_Max);
figure
scatter(N,l1norm,'filled')
hold on;
scatter(N,l2normadj,'filled')
scatter(N,l2norm,'filled')
set(gca,'xscale','log')
set(gca,'yscale','log')
legend('l1norm','l2norm-adjusted (divided by J)', 'l2norm')
title('Keep N/J^2')
hold off;

[l1norm,l2normadj,l2norm] = checknorms(N,MM,T,X_Max);
figure
scatter(N,l1norm,'filled')
hold on;
scatter(N,l2normadj,'filled')
scatter(N,l2norm,'filled')
set(gca,'xscale','log')
set(gca,'yscale','log')
legend('l1norm','l2norm-adjusted (divided by J)', 'l2norm')
title('Keep N/J')
hold off;

