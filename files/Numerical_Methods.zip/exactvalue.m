function [result] = exactvalue(x,t)
    result = 0;
    NN = 10;
    for i = 0:NN
        result = result + 2*sin((2*i+1)*pi*x)*sin((2*i+1)*pi/2)*exp(-(2*i+1)*(2*i+1)*pi*pi*t/2);
    end
end

