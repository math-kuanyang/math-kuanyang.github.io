function [u] = euler(N,M,T,X_Max)

dx = X_Max/N;
dt = T/M;
p  = 0.5*dt/dx^2;% p

x = (0:N)*dx;
u = zeros(1,N+1);

u(1+N/2) = 1/dx;  % Discrete dirac initial data

for i = 1:M
  u(1) = 0;
  u(N+1) = 0;
  for n = 2:N
    u(n) = p*u(n-1) + (1-2*p)*u(n) + p*u(n+1);
  end
end

end

