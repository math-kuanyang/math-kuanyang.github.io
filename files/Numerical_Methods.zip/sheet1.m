N = 10;
M = 20;
T = 0.05;
X_Max = 1;
u = euler(N,M,T,X_Max);

%[infnorm, l2norm] = twonorm(u);

figure
x = linspace(0,1,N+1);
y = linspace(0,1,max(1001,N+1));
plot(x, u);
hold on;
plot(y, exactvalue(y,T));
hold off
legend('Euler Scheme','Analytic Solution')





        
