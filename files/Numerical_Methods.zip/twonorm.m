function [infnorm,l2norm] = twonorm(u)
%INFNORM Summary of this function goes here
%   Detailed explanation goes here
N = length(u);
T = 0.05;
x = linspace(0,1,N);
infnorm = 0;
l2norm = 0;
for i = 1:N
    if abs(u(i) - exactvalue(x(i),T)) > infnorm
        infnorm = abs(u(i) - exactvalue(x(i),T));
    end
    l2norm = l2norm + (u(i) - exactvalue(x(i),T))^2;
end
l2norm = sqrt(l2norm);
end

