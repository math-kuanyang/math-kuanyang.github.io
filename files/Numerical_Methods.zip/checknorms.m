function [l1norm, l2normadj,l2norm] = checknorms(N,M,T,X_Max)
l1norm = zeros(1,length(N));
l2normadj = zeros(1,length(N));
l2norm = zeros(1,length(N));
for i = 1:length(N)
    u = euler(N(i),M(i),T,X_Max);
    [l1,l2] = twonorm(u);
    l1norm(i) = l1;
    l2normadj(i) = l2/N(i);
    l2norm(i) = l2;
end
end

